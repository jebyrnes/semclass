#Load your Data File
keeley<-read.csv("./Keeley_rawdata_select4.csv")

#examine the data 
head(keeley)

#load the library
library(lavaan)

#A simple model
model<-'cover ~ firesev + age
        firesev ~ age'

#fit it
fit<-sem(model, data=keeley)

#Fit and Coefficients
summary(fit)

#Standardized Coefficients
standardizedSolution(fit)